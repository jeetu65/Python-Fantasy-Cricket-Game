# Magical Arena

## Welcome to the Magical Arena!

Embark on an epic journey where powerful wizards clash in a battle of wit and magic! "Magical Arena" is a Java console game that transports you to a mystical world filled with arcane spells, strategic maneuvers, and thrilling combat.

## How to Play

1. **Download**: Get started by downloading the game files from the repository.

2. **Compile and Run**: Open your terminal or command prompt, navigate to the game directory, and compile the Java files using the following commands:
   ```bash
   javac Main.java
   java Main
