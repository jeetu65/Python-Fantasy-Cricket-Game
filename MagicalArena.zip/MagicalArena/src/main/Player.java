package main;

import java.util.Random;

public class Player {
    private int health;
    private int strength;
    private int attack;
    private String name;
    private Random random;

    public Player(int health, int strength, int attack, String name) {
        this.health = health;
        this.strength = strength;
        this.attack = attack;
        this.name = name;
        this.random = new Random();
    }

    public int getHealth() {
        return health;
    }

    public String getName() {
        return name;
    }

    public boolean isAlive() {
        return health > 0;
    }

    public void receiveDamage(int damage) {
        health = Math.max(0, health - damage);
    }

    public int rollDice() {
        return random.nextInt(6) + 1;
    }

    public int calculateAttackDamage() {
        return attack * rollDice();
    }

    public int calculateDefendStrength() {
        return strength * rollDice();
    }
}
