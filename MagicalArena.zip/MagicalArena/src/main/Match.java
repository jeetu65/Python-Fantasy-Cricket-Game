package main;

public class Match {
    private Player playerA;
    private Player playerB;

    public Match(Player playerA, Player playerB) {
        this.playerA = playerA;
        this.playerB = playerB;
    }

    public void start() {
        Player attacker = (playerA.getHealth() <= playerB.getHealth()) ? playerA : playerB;
        Player defender = (attacker == playerA) ? playerB : playerA;

        System.out.println("Starting match between " + playerA.getName() + " and " + playerB.getName());
        System.out.println(attacker.getName() + " will start attacking");

        int rounds = 0;

        while (playerA.isAlive() && playerB.isAlive()) {
            pause();
            System.out.println("\nRound: " + ++rounds);
            attack(attacker, defender);

            // Swap attacker and defender
            Player temp = attacker;
            attacker = defender;
            defender = temp;
        }

        Player winner = playerA.isAlive() ? playerA : playerB;
        System.out.println("\nWinner: " + winner.getName() + " in " + rounds + " rounds");
    }

    private void attack(Player attacker, Player defender) {
        System.out.println(attacker.getName() + " attacks!");
        int damage = Math.max(0, attacker.calculateAttackDamage() - defender.calculateDefendStrength());
        System.out.println(attacker.getName() + " deals " + damage + " damage to " + defender.getName());
        defender.receiveDamage(damage);
        System.out.println(defender.getName() + " has " + defender.getHealth() + " health remaining");
    }

    //Adds a one-second delay between rounds to make the match easier to follow
    private void pause() {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ignored) {
        }
    }
}
