import main.Match;
import main.Player;

import java.util.Scanner;

public class MainApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create players with user input
        Player playerA = initPlayer(scanner, "main.Player A");
        Player playerB = initPlayer(scanner, "main.Player B");

        // Start the match
        Match match = new Match(playerA, playerB);
        match.start();

        scanner.close();
    }

    // Method to create a player with user input
    private static Player initPlayer(Scanner scanner, String name) {
        System.out.println("Enter attributes for " + name);

        System.out.print("Health: ");
        int health = scanner.nextInt();

        System.out.print("Strength: ");
        int strength = scanner.nextInt();

        System.out.print("Attack: ");
        int attack = scanner.nextInt();

        return new Player(health, strength, attack, name);
    }
}
