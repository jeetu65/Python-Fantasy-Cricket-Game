package unitTest;

import main.Player;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class PlayerTest {
    private Player player;

    @BeforeEach
    public void setUp() {
        player = new Player(100, 10, 10, "TestPlayer");
    }

    @Test
    public void testInitialHealth() {
        assertEquals(100, player.getHealth());
    }

    @Test
    public void testReceiveDamage() {
        player.receiveDamage(10);
        assertEquals(90, player.getHealth());
    }

    @Test
    public void testReceiveExcessiveDamage() {
        player.receiveDamage(200);
        assertEquals(0, player.getHealth());
    }

    @Test
    public void testIsAlive() {
        assertTrue(player.isAlive());
        player.receiveDamage(100);
        assertFalse(player.isAlive());
    }

    @Test
    public void testRollDice() {
        int diceRoll = player.rollDice();
        assertTrue(diceRoll >= 1 && diceRoll <= 6);
    }

    @Test
    public void testCalculateAttackDamage() {
        int attackDamage = player.calculateAttackDamage();
        assertTrue(attackDamage >= 10 && attackDamage <= 60);
    }

    @Test
    public void testCalculateDefendStrength() {
        int defendStrength = player.calculateDefendStrength();
        assertTrue(defendStrength >= 10 && defendStrength <= 60);
    }
}

