package unitTest;


import main.Match;
import main.Player;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

public class MatchTest {
    @Test
    public void testMatch() {
        ByteArrayOutputStream outputStreamCaptor = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStreamCaptor));

        Player playerA = new Player(100, 10, 10, "PlayerA");
        Player playerB = new Player(100, 10, 10, "PlayerB");

        Match match = new Match(playerA, playerB);

        match.start();

        System.setOut(System.out);

        String output = outputStreamCaptor.toString();

        assertTrue(output.contains("Starting match between PlayerA and PlayerB"));
        assertTrue(output.contains("Round: 1"));
        assertTrue(output.contains("attacks!"));
        assertTrue(output.contains("damage to"));
        assertTrue(output.contains("health remaining"));
        assertTrue(output.contains("Winner:"));
    }
}

